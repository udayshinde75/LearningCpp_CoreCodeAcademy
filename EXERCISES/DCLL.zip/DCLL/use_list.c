#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "list.h"

int main(void)
{
	list_t* p_list = NULL;
	list_t* p_reversed_list = NULL;
	list_t* p_list_1 = NULL;
	list_t* p_list_2 = NULL;
	list_t* p_concat_list = NULL;
	list_t* p_merged_list = NULL;
	list_t* p_from_array = NULL;
	data_t* p_array = NULL;
	len_t arr_len = 0;
	data_t data;

	/* === Phase 1: Creation and empty-list guards === */

	p_list = create_list();
	assert(p_list);
	show_list(p_list, "After creation:");

	assert(is_list_empty(p_list) == TRUE);
	assert(get_list_length(p_list) == 0);
	assert(get_start(p_list, &data) == LIST_EMPTY);
	assert(get_end(p_list, &data) == LIST_EMPTY);
	assert(pop_start(p_list, &data) == LIST_EMPTY);
	assert(pop_end(p_list, &data) == LIST_EMPTY);
	assert(remove_start(p_list) == LIST_EMPTY);
	assert(remove_end(p_list) == LIST_EMPTY);

	/* === Phase 2: Insertions === */

	for(data = 0; data < 5; ++data)
		assert(insert_start(p_list, data) == SUCCESS);
	show_list(p_list, "After insert_start(0..4):");

	for(data = 5; data < 10; ++data)
		assert(insert_end(p_list, data) == SUCCESS);
	show_list(p_list, "After insert_end(5..9):");

	assert(insert_after(p_list, -10, 100) == LIST_DATA_NOT_FOUND);
	assert(insert_before(p_list, 300, 200) == LIST_DATA_NOT_FOUND);

	assert(insert_after(p_list, 0, 100) == SUCCESS);
	show_list(p_list, "After insert_after(0, 100):");
	assert(insert_before(p_list, 0, 200) == SUCCESS);
	show_list(p_list, "After insert_before(0, 200):");

	/* === Phase 3: Accessors === */

	assert(get_list_length(p_list) > 0);
	data = -1;
	assert(get_start(p_list, &data) == SUCCESS);
	printf("Start Data:%d\n", data);

	data = -1;
	assert(get_end(p_list, &data) == SUCCESS);
	printf("End Data:%d\n", data);

	/* === Phase 4: Pop === */

	data = -1;
	assert(pop_start(p_list, &data) == SUCCESS);
	printf("Popped Start:%d\n", data);
	show_list(p_list, "After pop_start:");

	data = -1;
	assert(pop_end(p_list, &data) == SUCCESS);
	printf("Popped End:%d\n", data);
	show_list(p_list, "After pop_end:");

	/* === Phase 5: Remove === */

	assert(remove_start(p_list) == SUCCESS);
	show_list(p_list, "After remove_start:");

	assert(remove_end(p_list) == SUCCESS);
	show_list(p_list, "After remove_end:");

	assert(remove_data(p_list, -10) == LIST_DATA_NOT_FOUND);
	assert(remove_data(p_list, 0) == SUCCESS);
	show_list(p_list, "After remove_data(0):");

	/* === Phase 6: Query === */

	printf("Length = %d\n", get_list_length(p_list));
	assert(is_list_empty(p_list) == FALSE);

	if(find_in_list(p_list, -10) == FALSE)
		puts("-10 is not present in list");
	if(find_in_list(p_list, 2) == TRUE)
		puts("2 is present in list");

	/* === Phase 7: to_array and to_list round-trip === */

	to_array(p_list, &p_array, &arr_len);
	printf("to_array: length=%d, elements:", arr_len);
	for(data = 0; data < arr_len; ++data)
		printf(" %d", p_array[data]);
	puts("");

	p_from_array = to_list(p_array, arr_len);
	show_list(p_from_array, "to_list (round-trip):");
	assert(destroy_list(&p_from_array) == SUCCESS && p_from_array == NULL);
	free(p_array);
	p_array = NULL;

	/* === Phase 8: Reversal (immutable) === */

	show_list(p_list, "Before get_reversed_list:");
	p_reversed_list = get_reversed_list(p_list);
	show_list(p_reversed_list, "Reversed copy:");
	show_list(p_list, "Original unchanged:");
	assert(destroy_list(&p_reversed_list) == SUCCESS && p_reversed_list == NULL);

	/* === Phase 9: Reversal (mutable) === */

	show_list(p_list, "Before reverse_list:");
	assert(reverse_list(p_list) == SUCCESS);
	show_list(p_list, "After reverse_list:");

	/* === Phase 10: Drain, edge cases === */

	while(is_list_empty(p_list) != TRUE)
		assert(remove_end(p_list) == SUCCESS);

	assert(is_list_empty(p_list) == TRUE);
	show_list(p_list, "Drained to empty:");
	assert(reverse_list(p_list) == SUCCESS);
	show_list(p_list, "Reverse of empty:");

	assert(insert_end(p_list, 100) == SUCCESS);
	show_list(p_list, "Single element:");
	assert(reverse_list(p_list) == SUCCESS);
	show_list(p_list, "Reverse of single element:");

	assert(destroy_list(&p_list) == SUCCESS && p_list == NULL);

	/* === Phase 11: Inter-list operations === */

	puts("--- Inter-list routines ---");

	p_list_1 = create_list();
	p_list_2 = create_list();
	assert(is_list_empty(p_list_1) == TRUE && is_list_empty(p_list_2) == TRUE);
	p_merged_list = merge_lists(p_list_1, p_list_2);
	assert(is_list_empty(p_merged_list) == TRUE);
	assert(destroy_list(&p_merged_list) == SUCCESS && p_merged_list == NULL);

	for(data = 5; data <= 95; data += 10)
		assert(insert_end(p_list_1, data) == SUCCESS);
	for(data = 10; data <= 60; data += 10)
		assert(insert_end(p_list_2, data) == SUCCESS);

	show_list(p_list_1, "p_list_1:");
	show_list(p_list_2, "p_list_2:");

	p_concat_list = get_concated_list(p_list_1, p_list_2);
	show_list(p_concat_list, "get_concated_list:");
	show_list(p_list_1, "p_list_1 unchanged:");
	show_list(p_list_2, "p_list_2 unchanged:");

	p_merged_list = merge_lists(p_list_1, p_list_2);
	show_list(p_merged_list, "merge_lists:");

	assert(concat_lists(p_list_1, &p_list_2) == SUCCESS && p_list_2 == NULL);
	show_list(p_list_1, "p_list_1 after concat_lists:");

	/* === Phase 12: clear_list === */

	assert(clear_list(p_concat_list) == SUCCESS);
	show_list(p_concat_list, "p_concat_list after clear_list:");
	assert(is_list_empty(p_concat_list) == TRUE);

	/* === Cleanup === */

	assert(destroy_list(&p_concat_list) == SUCCESS && p_concat_list == NULL);
	assert(destroy_list(&p_merged_list) == SUCCESS && p_merged_list == NULL);
	assert(destroy_list(&p_list_1) == SUCCESS && p_list_1 == NULL);

	puts("Implementation successful");
	return (EXIT_SUCCESS);
}
